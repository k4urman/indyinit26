const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["chunks/mock-background-Cc4SSgeR.js","chunks/jsx-runtime-CnZeCAFY.js"])))=>i.map(i=>d[i]);
import{C as e,S as t,_ as n,a as r,b as i,c as a,d as o,f as s,g as c,h as l,i as u,m as d,o as f,p,s as m,t as h,u as g,v as _,x as v,y}from"./jsx-runtime-CnZeCAFY.js";import{t as b}from"./theme-Df4KRfVP.js";var x=e(v(),1),S=e(t(),1),C=h(),w=`
${b}
body { width: 380px; min-height: 540px; overflow-x: hidden; }
.app { padding: 18px 16px 14px; display: grid; gap: 14px; }
.head { display: flex; align-items: center; justify-content: space-between; }
.logo { display: flex; align-items: center; gap: 7px; font-weight: 600; font-size: 17px; }
.switch { display: inline-flex; align-items: center; gap: 8px; font-size: 13px; color: var(--muted); }
.track { position: relative; width: 51px; height: 31px; border-radius: 99px; background: var(--line); transition: background .2s; }
.track[aria-checked="true"] { background: #34c759; }
.knob { position: absolute; top: 2px; left: 2px; width: 27px; height: 27px; border-radius: 50%; background: #fff; box-shadow: 0 3px 8px rgba(0,0,0,.15), 0 1px 1px rgba(0,0,0,.16); transition: left .2s; }
.track[aria-checked="true"] .knob { left: 22px; }

.hero { padding: 4px 2px 0; }
.hero .n { font-size: 48px; font-weight: 600; letter-spacing: -.03em; line-height: 1; }
.hero .l { font-size: 15px; color: var(--muted); margin-top: 4px; }
.hero .l b { color: var(--text); font-weight: 500; }

.group { border-radius: 12px; background: var(--surface); overflow: hidden; animation: appear .3s both; }
.label { font-size: 13px; color: var(--muted); padding: 0 4px 6px; }
.site { display: grid; grid-template-columns: 34px 1fr; gap: 12px; align-items: center; padding: 14px; }
.sym { width: 34px; height: 34px; }
.sym.safe { color: var(--green); } .sym.caution { color: var(--orange); } .sym.danger { color: var(--red); } .sym.unknown { color: var(--dim); }
.sym.loading { animation: spin 1s linear infinite; }
@keyframes spin { to { transform: rotate(360deg) } }
.domain { font-size: 13px; color: var(--muted); word-break: break-all; }
.verdict { font-size: 17px; font-weight: 600; }
.desc { font-size: 13px; color: var(--muted); }
.reasons { list-style: none; border-top: 1px solid var(--line-soft); margin-left: 14px; }
.reasons li { padding: 10px 14px 10px 0; border-bottom: 1px solid var(--line-soft); font-size: 13px; color: var(--muted); }
.reasons li:last-child { border-bottom: 0; }
.reasons b { display: block; color: var(--text); font-size: 14px; font-weight: 500; }
.row { display: grid; grid-template-columns: repeat(3, 1fr); border-top: 1px solid var(--line-soft); }
.row button { min-height: 44px; font-size: 14px; color: var(--link); border-right: 1px solid var(--line-soft); }
.row button:last-child { border-right: 0; }
.row button[aria-pressed="true"] { color: var(--text); font-weight: 600; }
.row button:disabled { color: var(--dim); cursor: default; }
.note { padding: 0 14px 12px; font-size: 12.5px; color: var(--muted); }

.check { display: flex; gap: 8px; padding: 10px; }
.check input { flex: 1; min-width: 0; height: 40px; padding: 0 12px; border-radius: 10px; border: 1px solid var(--line); background: var(--bg); font-size: 15px; }
.check input::placeholder { color: var(--dim); }
.check .btn-primary { min-height: 40px; padding: 0 18px; }
.result { margin: 0 10px 10px; padding: 10px 12px; border-radius: 10px; font-size: 13px; }
.result.safe, .result.unknown { background: var(--green-tint); } .result.caution { background: var(--orange-tint); } .result.danger { background: var(--red-tint); }
.result b { display: block; font-size: 14px; font-weight: 600; }
.result.danger b { color: var(--red); } .result.caution b { color: var(--orange); } .result.safe b, .result.unknown b { color: var(--green); }
.result span { color: var(--muted); }
.err { padding: 0 14px 12px; color: var(--red); font-size: 13px; }

.events { list-style: none; }
.events li { display: grid; grid-template-columns: 1fr auto; gap: 0 8px; padding: 10px 14px; border-bottom: 1px solid var(--line-soft); font-size: 13px; }
.events li:last-child { border-bottom: 0; }
.events .d { font-weight: 500; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.events .a { font-size: 12px; color: var(--muted); }
.events .t { grid-column: 1 / -1; color: var(--dim); font-size: 12px; }

.foot { display: flex; align-items: center; justify-content: space-between; padding: 2px 4px 0; font-size: 12px; color: var(--dim); }
.foot button { color: var(--link); font-size: 13px; }
.off .hero, .off .group { opacity: .5; }
`;function T({size:e=20}){return(0,C.jsx)(`svg`,{width:e,height:e,viewBox:`0 0 24 24`,"aria-hidden":`true`,children:(0,C.jsx)(`path`,{fill:`currentColor`,d:`M12 2 4 5v6.2c0 5 3.4 9.4 8 10.8 4.6-1.4 8-5.8 8-10.8V5z`})})}function E({severity:e,loading:t}){let n={width:34,height:34,viewBox:`0 0 24 24`};return t?(0,C.jsx)(`svg`,{...n,fill:`none`,stroke:`currentColor`,strokeWidth:`2.2`,strokeLinecap:`round`,children:(0,C.jsx)(`path`,{d:`M12 3a9 9 0 1 1-9 9`})}):e===`safe`?(0,C.jsxs)(`svg`,{...n,children:[(0,C.jsx)(`path`,{fill:`currentColor`,d:`M12 2 4 5v6.2c0 5 3.4 9.4 8 10.8 4.6-1.4 8-5.8 8-10.8V5z`}),(0,C.jsx)(`path`,{d:`m8.3 12.2 2.6 2.6 5-5.2`,fill:`none`,stroke:`#fff`,strokeWidth:`2`,strokeLinecap:`round`,strokeLinejoin:`round`})]}):e===`danger`?(0,C.jsxs)(`svg`,{...n,children:[(0,C.jsx)(`path`,{fill:`currentColor`,d:`M8.2 2h7.6L22 8.2v7.6L15.8 22H8.2L2 15.8V8.2z`}),(0,C.jsx)(`path`,{d:`m9 9 6 6m0-6-6 6`,stroke:`#fff`,strokeWidth:`2.2`,strokeLinecap:`round`})]}):e===`caution`?(0,C.jsxs)(`svg`,{...n,children:[(0,C.jsx)(`path`,{fill:`currentColor`,d:`M10.3 3.4a2 2 0 0 1 3.4 0l8.4 14.5a2 2 0 0 1-1.7 3H3.6a2 2 0 0 1-1.7-3z`}),(0,C.jsx)(`path`,{d:`M12 9v4.5M12 17h.01`,stroke:`#fff`,strokeWidth:`2.2`,strokeLinecap:`round`})]}):(0,C.jsxs)(`svg`,{...n,children:[(0,C.jsx)(`circle`,{cx:`12`,cy:`12`,r:`10`,fill:`currentColor`}),(0,C.jsx)(`path`,{d:`M12 7.5v5.5M12 16.5h.01`,stroke:`#fff`,strokeWidth:`2.2`,strokeLinecap:`round`})]})}var D={safe:`Looks safe`,unknown:`Not checked`,caution:`Be careful here`,danger:`Looks like a scam`},O={safe:`No problems found`,unknown:`No problems found`,caution:`Be careful with this link`,danger:`Do not open this link`};function k(){let[e,t]=(0,S.useState)(g),[h,v]=(0,S.useState)(p),[b,x]=(0,S.useState)(null),[k,A]=(0,S.useState)(!0),[j,M]=(0,S.useState)(``),[N,P]=(0,S.useState)(null),[F,I]=(0,S.useState)(!1),[L,R]=(0,S.useState)(``),[z,B]=(0,S.useState)(!1);(0,S.useEffect)(()=>{(async()=>{try{let[e,n]=await Promise.all([l(s.settings,{}),l(s.stats,p)]);if(t({...g,...e,categories:{...g.categories,...e.categories}}),v(n),d){let[e]=await i.tabs.query({active:!0,currentWindow:!0});e?.id!==void 0&&x(await c({type:`getTabStatus`,tabId:e.id}))}else{let{mockTabStatusDanger:e}=await y(async()=>{let{mockTabStatusDanger:e}=await import(`./mock-background-Cc4SSgeR.js`);return{mockTabStatusDanger:e}},__vite__mapDeps([0,1]));x(e)}}catch(e){console.error(`[sentinel] popup load`,e)}finally{A(!1)}})()},[]),(0,S.useEffect)(()=>{if(!d)return;let e=e=>{let n=e[s.settings]?.newValue;n&&t({...g,...n});let r=e[s.stats]?.newValue;r&&v(r)};return i.storage.onChanged.addListener(e),()=>i.storage.onChanged.removeListener(e)},[]);let V=(0,S.useCallback)(async()=>{let n={...e,enabled:!e.enabled};t(n),await _(s.settings,n)},[e]),H=(0,S.useCallback)(async e=>{if(!b?.domain)return;let t=b.listed===e?null:e;try{await c({type:`setList`,pattern:b.domain,kind:t}),x({...b,listed:t})}catch(e){R(e instanceof Error?e.message:u.generic)}},[b]),U=(0,S.useCallback)(async()=>{if(b?.url)try{await c({type:`reportScam`,url:b.url}),B(!0),x({...b,listed:`block`})}catch(e){R(e instanceof Error?e.message:u.generic)}},[b]),W=(0,S.useCallback)(async()=>{R(``),P(null);let e=j.trim();if(e){I(!0);try{P(await c({type:`checkUrl`,url:e}))}catch(e){R(e instanceof Error?e.message:u.invalidUrl)}finally{I(!1)}}},[j]),G=()=>d?void i.runtime.openOptionsPage():void 0,K=b?.verdict??null,q=!!(b?.url&&/^https?:/.test(b.url)),J=K?.severity??`unknown`,Y=n(h),X=h.today?.date===new Date().toISOString().slice(0,10)?h.today.blocked:0,Z=o.reduce((t,n)=>Math.abs(n.at-e.aggressiveness)<Math.abs(t.at-e.aggressiveness)?n:t,o[0]),Q=(b?.recent??[]).slice(-3).reverse();return(0,C.jsxs)(C.Fragment,{children:[(0,C.jsx)(`style`,{children:w}),(0,C.jsxs)(`main`,{className:`app ${e.enabled?``:`off`}`,children:[(0,C.jsxs)(`div`,{className:`head`,children:[(0,C.jsxs)(`div`,{className:`logo`,children:[(0,C.jsx)(T,{}),a]}),(0,C.jsxs)(`label`,{className:`switch`,children:[e.enabled?`On`:`Off`,(0,C.jsx)(`button`,{className:`track`,role:`switch`,"aria-checked":e.enabled,"aria-label":f.toggleAriaLabel,onClick:V,children:(0,C.jsx)(`span`,{className:`knob`})})]})]}),(0,C.jsxs)(`section`,{className:`hero`,"aria-label":`Protection summary`,children:[(0,C.jsx)(`div`,{className:`n`,children:Y.toLocaleString()}),(0,C.jsxs)(`div`,{className:`l`,children:[Y===1?`scam stopped`:`scams stopped`,X>0?`, ${X} today`:``,`. Protection level: `,(0,C.jsx)(`b`,{children:Z.label}),`.`]})]}),(0,C.jsxs)(`div`,{children:[(0,C.jsx)(`div`,{className:`label`,children:f.currentPage}),(0,C.jsx)(`section`,{className:`group`,"aria-label":f.currentPage,children:!q&&!k?(0,C.jsx)(`p`,{className:`site desc`,style:{display:`block`},children:f.noPage}):(0,C.jsxs)(C.Fragment,{children:[(0,C.jsxs)(`div`,{className:`site`,children:[(0,C.jsx)(`div`,{className:`sym ${k?`unknown loading`:J}`,children:(0,C.jsx)(E,{severity:J,loading:k})}),(0,C.jsxs)(`div`,{children:[(0,C.jsx)(`div`,{className:`verdict`,children:k?f.checking:b?.listed===`allow`?`You trust this site`:D[J]}),(0,C.jsx)(`div`,{className:`domain`,children:b?.domain||``})]})]}),K&&K.reasons.length>0&&(0,C.jsx)(`ul`,{className:`reasons`,children:K.reasons.slice(0,3).map(e=>(0,C.jsxs)(`li`,{children:[(0,C.jsx)(`b`,{children:e.title}),e.detail]},e.title))}),q&&(0,C.jsxs)(`div`,{className:`row`,children:[(0,C.jsx)(`button`,{"aria-pressed":b?.listed===`allow`,onClick:()=>H(`allow`),children:b?.listed===`allow`?`Trusted`:`Trust`}),(0,C.jsx)(`button`,{"aria-pressed":b?.listed===`block`,onClick:()=>H(`block`),children:b?.listed===`block`?`Blocked`:`Block`}),(0,C.jsx)(`button`,{onClick:U,disabled:z,children:z?`Reported`:`Report`})]}),z&&(0,C.jsx)(`p`,{className:`note`,children:`Blocked on this computer. You can also tell the FTC at reportfraud.ftc.gov.`})]})})]}),(0,C.jsxs)(`div`,{children:[(0,C.jsx)(`div`,{className:`label`,children:f.checkLinkLabel}),(0,C.jsxs)(`section`,{className:`group`,"aria-label":f.checkLinkLabel,children:[(0,C.jsxs)(`form`,{className:`check`,onSubmit:e=>{e.preventDefault(),W()},children:[(0,C.jsx)(`input`,{value:j,onChange:e=>M(e.target.value),placeholder:f.checkLinkPlaceholder,"aria-label":f.checkLinkPlaceholder,spellCheck:!1}),(0,C.jsx)(`button`,{className:`btn-primary`,disabled:F||!j.trim(),children:`Check`})]}),N&&(0,C.jsxs)(`div`,{className:`result ${N.severity}`,children:[(0,C.jsx)(`b`,{children:O[N.severity]}),(0,C.jsx)(`span`,{children:N.reasons[0]?`${N.reasons[0].title}. ${N.reasons[0].detail}`:`${N.domain} isn’t on any scam list and looks normal.`})]}),L&&(0,C.jsx)(`p`,{className:`err`,children:L})]})]}),Q.length>0&&(0,C.jsxs)(`div`,{children:[(0,C.jsx)(`div`,{className:`label`,children:f.recentEvents}),(0,C.jsx)(`section`,{className:`group`,"aria-label":f.recentEvents,children:(0,C.jsx)(`ul`,{className:`events`,children:Q.map(e=>(0,C.jsxs)(`li`,{children:[(0,C.jsx)(`span`,{className:`d`,children:e.reasons[0]?.title??e.domain}),(0,C.jsx)(`span`,{className:`a`,children:r.eventAction[e.userOverride??e.action]??e.action}),(0,C.jsx)(`span`,{className:`t`,children:m(e.ts)})]},e.id))})})]}),(0,C.jsxs)(`div`,{className:`foot`,children:[(0,C.jsx)(`span`,{children:`Checked on this device.`}),(0,C.jsx)(`button`,{onClick:G,children:`Settings`})]})]})]})}x.createRoot(document.getElementById(`root`)).render((0,C.jsx)(k,{}));